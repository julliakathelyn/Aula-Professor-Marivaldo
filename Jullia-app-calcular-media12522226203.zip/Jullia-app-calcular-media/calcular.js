let nome = ''
let notaPrimeiraAvaliacao = 0
let notaSegundaAvaliacao = 0
let notaTerceiraAvaliacao = 0
let notaQuartaAvaliacao = 0


nome = prompt("Digite o nome do aluno: ")
notaPrimeiraAvaliacao = Number(prompt("Digite a primeira nota: "))
notaSegundaAvaliacao = Number(prompt("Digite a segunda nota: "))
notaTerceiraAvaliacao = Number(prompt("Digite a terceira nota: "))
notaQuartaAvaliacao = Number(prompt("Digite a quarta nota: "))

function calcularMedia(nome, notaPrimeiraAvaliacao, notaSegundaAvaliacao, notaTerceiraAvaliacao, notaQuartaAvaliacao){
    let soma = notaPrimeiraAvaliacao + notaSegundaAvaliacao + notaTerceiraAvaliacao + notaQuartaAvaliacao
    let mediaDoAluno = soma / 4;
    let resultado = mediaDoAluno;
    alert(`A média de ${nome} é ${resultado}`);
}

calcularMedia(nome, notaPrimeiraAvaliacao, notaSegundaAvaliacao, notaTerceiraAvaliacao, notaQuartaAvaliacao);